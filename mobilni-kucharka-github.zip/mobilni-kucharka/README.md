# Mobilní Kuchařka

Zdrojový kód české kuchařky včetně fotografií receptů, úprav receptů, oblíbených a přepočtu množství surovin podle počtu porcí.

## Nahrání na GitHub bez příkazů

1. Rozbalte ZIP na počítači.
2. Na GitHubu vytvořte nový repozitář (New repository).
3. Vyberte Upload files (nebo Add file → Upload files).
4. Nahrajte **obsah** složky `mobilni-kucharka`, ne ZIP samotný. Zachovejte složky `src` a `public`. Nahrajte i skryté konfigurační soubory.
5. Potvrďte nahrání tlačítkem Commit changes.

Pokud webové nahrávání odmítne počet souborů, nahrajte je po částech nebo použijte GitHub Desktop: naklonujte nový repozitář, zkopírujte do něj obsah rozbalené složky a zvolte Commit a Push origin.

## Spuštění na počítači

Nainstalujte aktuální Node.js (22.12 nebo novější) a Bun podle https://bun.sh.
V terminálu otevřete složku projektu a spusťte:

```sh
bun install --frozen-lockfile
bun run dev
```

Otevřete místní adresu vypsanou v terminálu. Jde o zdrojový projekt, nikoli samostatný HTML soubor: neotevírejte jej dvojklikem.

## GitHub přes terminál

Vytvořte na GitHubu prázdný repozitář. Potom ve složce projektu spusťte následující příkazy a nahraďte `VAS-UCET` a `VAS-REPOZITAR` svými údaji:

```sh
git init
git add .
git commit -m "Mobilní kuchařka"
git branch -M main
git remote add origin https://github.com/VAS-UCET/VAS-REPOZITAR.git
git push -u origin main
```

## Důležité informace

- Archiv obsahuje zdrojový kód a všechny přibalené fotografie. Neobsahuje závislosti, výsledky sestavení, přihlašovací údaje ani interní metadata editoru.
- Vaše vlastní recepty, úpravy a oblíbené jsou uložené v konkrétním prohlížeči. Tento ZIP je nepřenáší.
- Nahrání na GitHub uloží kód; samo o sobě nezpřístupní fungující webovou aplikaci.
- Tento projekt používá TanStack Start, React a Tailwind CSS. Není připravený k přímému zveřejnění na GitHub Pages, které hostují pouze statické soubory. Veřejný web můžete nadále zveřejnit přes Lovable; jiné hostování potřebuje odpovídající nastavení.
