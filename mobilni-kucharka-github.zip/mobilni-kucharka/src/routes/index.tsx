import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BookOpen, Clock, Heart, Plus, Search, ShoppingBag, UtensilsCrossed, X, Minus } from "lucide-react";
import { defaultRecipes as baseRecipes, FALLBACK_IMAGE, type Category, type Recipe } from "@/lib/recipes";
import { moreRecipes } from "@/lib/more-recipes";
import { Pencil } from "lucide-react";

const defaultRecipes = [...baseRecipes, ...moreRecipes];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mobilní Kuchařka – české recepty" },
      { name: "description", content: "Mobilní kuchařka s českými recepty, vyhledáváním, oblíbenými a vlastními recepty." },
      { property: "og:title", content: "Mobilní Kuchařka – české recepty" },
      { property: "og:description", content: "Svíčková, guláš, řízek a další české klasiky v kapse." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const STORAGE = "kucharka_recipes_v1";
const CATS: ("all" | Category)[] = ["all", "Hlavní chod", "Polévky", "Dezerty"];
const catLabel = (c: string) => (c === "all" ? "Vše" : c === "Hlavní chod" ? "Hlavní chody" : c);

function Index() {
  const [recipes, setRecipes] = useState<Recipe[]>(defaultRecipes);
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState<"all" | "fav">("all");
  const [cat, setCat] = useState<"all" | Category>("all");
  const [q, setQ] = useState("");
  const [detail, setDetail] = useState<Recipe | null>(null);
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Recipe | null>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE);
      if (saved) {
        const parsed: Recipe[] = JSON.parse(saved);
        // keep bundled images fresh for default recipes
        const fixed = parsed.map((r) => {
          const d = defaultRecipes.find((x) => x.id === r.id);
          return d && !r.image.startsWith("data:") ? { ...r, image: d.image } : r;
        });
        const missing = defaultRecipes.filter((d) => !parsed.some((r) => r.id === d.id));
        setRecipes([...fixed, ...missing]);
      }
    } catch {}
    setLoaded(true);
  }, []);
  useEffect(() => {
    if (loaded) localStorage.setItem(STORAGE, JSON.stringify(recipes));
  }, [recipes, loaded]);

  const list = useMemo(() => {
    const s = q.toLowerCase();
    return recipes.filter(
      (r) =>
        (tab === "all" || r.favorite) &&
        (cat === "all" || r.category === cat) &&
        (!s || r.title.toLowerCase().includes(s) || r.ingredients.some((i) => i.toLowerCase().includes(s))),
    );
  }, [recipes, tab, cat, q]);

  const toggleFav = (id: string) => setRecipes((rs) => rs.map((r) => (r.id === id ? { ...r, favorite: !r.favorite } : r)));

  return (
    <div className="mx-auto min-h-screen max-w-md border-x border-border bg-background pb-24 text-foreground">
      <header className="sticky top-0 z-20 flex items-center gap-2 bg-primary px-4 py-3 text-primary-foreground shadow-md">
        <div className="rounded-xl bg-primary-foreground/20 p-1.5"><UtensilsCrossed className="h-5 w-5" /></div>
        <h1 className="font-display text-xl font-bold">Mobilní Kuchařka</h1>
      </header>

      <section className="space-y-2 border-b border-border bg-card p-3">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-primary" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Hledat recept nebo surovinu..."
            className="w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div className="flex gap-1.5 overflow-x-auto text-xs">
          {CATS.map((c) => (
            <button key={c} onClick={() => setCat(c)}
              className={`shrink-0 rounded-full px-3 py-1 font-semibold ${cat === c ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
              {catLabel(c)}
            </button>
          ))}
        </div>
      </section>

      <main className="flex flex-col gap-3 p-3">
        {list.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">Nic jsme nenašli.</p>}
        {list.map((r) => (
          <article key={r.id} onClick={() => setDetail(r)} className="cursor-pointer overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition active:scale-[0.99]">
            <div className="relative">
              <img src={r.image} alt={r.title} loading="lazy" width={1024} height={768} className="h-40 w-full object-cover"
                onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }} />
              <button aria-label="Oblíbené" onClick={(e) => { e.stopPropagation(); toggleFav(r.id); }}
                className="absolute right-2 top-2 rounded-full bg-card/90 p-2 shadow">
                <Heart className={`h-4 w-4 ${r.favorite ? "fill-destructive text-destructive" : "text-muted-foreground"}`} />
              </button>
              <span className="absolute left-2 top-2 rounded-full bg-card/90 px-2 py-0.5 text-[10px] font-bold text-primary">{r.category}</span>
            </div>
            <div className="p-3">
              <h2 className="font-display text-lg font-bold leading-tight">{r.title}</h2>
              <div className="mt-1 flex gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{r.time} min</span>
                <span className="flex items-center gap-1"><ShoppingBag className="h-3 w-3" />{r.ingredients.length} surovin</span>
              </div>
            </div>
          </article>
        ))}
      </main>

      <button onClick={() => setAdding(true)} aria-label="Přidat recept"
        className="fixed bottom-20 left-1/2 z-20 ml-[150px] -translate-x-1/2 rounded-full bg-primary p-4 text-primary-foreground shadow-lg max-[420px]:left-auto max-[420px]:right-4 max-[420px]:ml-0 max-[420px]:translate-x-0">
        <Plus className="h-6 w-6" />
      </button>

      <nav className="fixed bottom-0 left-1/2 z-20 flex w-full max-w-md -translate-x-1/2 border-t border-border bg-card">
        {([["all", "Všechny", BookOpen], ["fav", "Oblíbené", Heart]] as const).map(([k, l, Icon]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`flex flex-1 flex-col items-center py-2 text-xs font-semibold ${tab === k ? "text-primary" : "text-muted-foreground"}`}>
            <Icon className="h-5 w-5" />{l}
          </button>
        ))}
      </nav>

      {detail && <Detail r={detail} onClose={() => setDetail(null)} onEdit={() => { setEditing(detail); setDetail(null); }} />}
      {editing && <AddForm initial={editing} onClose={() => setEditing(null)} onSave={(r) => { setRecipes((rs) => rs.map((x) => (x.id === r.id ? r : x))); setEditing(null); }} />}
      {adding && <AddForm onClose={() => setAdding(false)} onSave={(r) => { setRecipes((rs) => [r, ...rs]); setAdding(false); }} />}
    </div>
  );
}

function Sheet({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-foreground/60 sm:items-center" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="relative max-h-[90vh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-card shadow-2xl sm:rounded-2xl">
        <button onClick={onClose} aria-label="Zavřít" className="absolute right-3 top-3 z-10 rounded-full bg-card/90 p-2 shadow"><X className="h-4 w-4" /></button>
        {children}
      </div>
    </div>
  );
}

// Recepty jsou psané pro 4 porce
const BASE_PORTIONS = 4;

function formatAmount(n: number) {
  const r = n >= 10 ? Math.round(n) : Math.round(n * 10) / 10;
  return String(r).replace(".", ",");
}

// Přepočítá číslo na začátku suroviny (např. "100g cibule", "1/4 celeru", "0,5 l mléka")
function scaleIngredient(ing: string, factor: number) {
  if (factor === 1) return ing;
  return ing.replace(/^(\d+)\s*\/\s*(\d+)|^(\d+(?:[.,]\d+)?)/, (m, a, b, c) => {
    const val = a ? Number(a) / Number(b) : Number(String(c).replace(",", "."));
    return formatAmount(val * factor);
  });
}

function Detail({ r, onClose, onEdit }: { r: Recipe; onClose: () => void; onEdit: () => void }) {
  const [portions, setPortions] = useState(BASE_PORTIONS);
  const [done, setDone] = useState<number[]>([]);
  return (
    <Sheet onClose={onClose}>
      <img src={r.image} alt={r.title} className="h-52 w-full object-cover" onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }} />
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h2 className="font-display text-2xl font-bold">{r.title}</h2>
          <button onClick={onEdit} className="flex shrink-0 items-center gap-1 rounded-full bg-secondary px-3 py-1.5 text-xs font-bold text-secondary-foreground"><Pencil className="h-3 w-3" />Upravit</button>
        </div>
        <div className="mt-2 flex items-center justify-between text-sm text-muted-foreground">
          <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{r.time} min</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPortions((p) => Math.max(1, p - 1))} className="rounded-full bg-secondary p-1"><Minus className="h-3 w-3" /></button>
            <span className="font-semibold text-foreground">{portions} porce</span>
            <button onClick={() => setPortions((p) => p + 1)} className="rounded-full bg-secondary p-1"><Plus className="h-3 w-3" /></button>
          </div>
        </div>
        <h3 className="mb-2 mt-4 font-bold">Suroviny</h3>
        <ul className="space-y-1.5 rounded-xl bg-secondary/60 p-3 text-sm">
          {r.ingredients.map((ing, i) => (
            <li key={i}>
              <label className="flex cursor-pointer items-center gap-2">
                <input type="checkbox" checked={done.includes(i)} onChange={() => setDone((d) => (d.includes(i) ? d.filter((x) => x !== i) : [...d, i]))} className="accent-primary" />
                <span className={done.includes(i) ? "text-muted-foreground line-through" : ""}>{scaleIngredient(ing, portions / BASE_PORTIONS)}</span>
              </label>
            </li>
          ))}
        </ul>
        <h3 className="mb-2 mt-4 font-bold">Postup</h3>
        <div className="space-y-2 text-sm leading-relaxed">
          {r.instructions.split("\n").map((s, i) => <p key={i}>{s}</p>)}
        </div>
      </div>
    </Sheet>
  );
}

function AddForm({ initial, onClose, onSave }: { initial?: Recipe; onClose: () => void; onSave: (r: Recipe) => void }) {
  const [image, setImage] = useState(initial?.image ?? "");
  const onFile = (f?: File) => {
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => setImage(String(rd.result));
    rd.readAsDataURL(f);
  };
  const field = "w-full rounded-xl border border-input bg-background p-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring";
  return (
    <Sheet onClose={onClose}>
      <form className="space-y-3 p-4 text-sm" onSubmit={(e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        onSave({
          id: initial?.id ?? String(Date.now()),
          title: String(f.get("title")),
          category: f.get("category") as Category,
          time: Number(f.get("time")) || 30,
          image: image || FALLBACK_IMAGE,
          ingredients: String(f.get("ingredients")).split(",").map((s) => s.trim()).filter(Boolean),
          instructions: String(f.get("instructions")),
          favorite: initial?.favorite ?? false,
        });
      }}>
        <h2 className="font-display text-xl font-bold">{initial ? "Upravit recept" : "Přidat nový recept"}</h2>
        <input name="title" defaultValue={initial?.title} required placeholder="Název receptu" className={field} />
        <label className="block rounded-xl border border-dashed border-input p-3 text-center text-muted-foreground">
          {image ? <img src={image} alt="Náhled" className="h-28 w-full rounded-lg object-cover" /> : "Vybrat fotku"}
          <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
        </label>
        <div className="grid grid-cols-2 gap-2">
          <select name="category" defaultValue={initial?.category} className={field}><option>Hlavní chod</option><option>Polévky</option><option>Dezerty</option></select>
          <input name="time" type="number" defaultValue={initial?.time} placeholder="Čas (min)" className={field} />
        </div>
        <input name="ingredients" defaultValue={initial?.ingredients.join(", ")} required placeholder="Suroviny oddělené čárkou" className={field} />
        <textarea name="instructions" defaultValue={initial?.instructions} required rows={6} placeholder="Postup" className={field} />
        <button className="w-full rounded-xl bg-primary py-2.5 font-bold text-primary-foreground">{initial ? "Uložit změny" : "Uložit recept"}</button>
      </form>
    </Sheet>
  );
}
