import polevka from "@/assets/cat-polevka.jpg";
import hlavni from "@/assets/cat-hlavni.jpg";
import dezert from "@/assets/cat-dezert.jpg";
import type { Category, Recipe } from "./recipes";

const IMG: Record<Category, string> = { "Polévky": polevka, "Hlavní chod": hlavni, "Dezerty": dezert };
const recipeImages = import.meta.glob<string>("/src/assets/recipes-more/*.jpg", {
  eager: true,
  import: "default",
  query: "?url",
});

const imageFor = (index: number, category: Category) =>
  recipeImages[`/src/assets/recipes-more/recipe-${String(index + 1).padStart(2, "0")}.jpg`] ?? IMG[category];

// [title, category, time, ingredients (comma), steps (|)]
const raw: [string, Category, number, string, string][] = [
  ["Česnečka se sýrem a krutony", "Polévky", 25, "6 stroužků česneku, 3 brambory, 1 l vývaru, kmín, majoránka, sýr eidam, chléb na krutony", "Brambory nakrájíme a uvaříme ve vývaru s kmínem.|Přidáme prolisovaný česnek a majoránku.|Podáváme se strouhaným sýrem a opečenými krutony."],
  ["Kulajda", "Polévky", 45, "4 brambory, hrst hub, 200 ml smetany, 2 lžíce mouky, kopr, ocet, 4 vejce", "Brambory a houby uvaříme ve vodě s kmínem.|Zahustíme smetanou rozmíchanou s moukou.|Dochutíme octem a koprem.|Podáváme se ztraceným vejcem."],
  ["Hovězí vývar s nudlemi", "Polévky", 180, "1 kg hovězích kostí, 300 g hovězího masa, kořenová zelenina, cibule, nudle, petrželka", "Kosti a maso zalijeme studenou vodou a pomalu vaříme.|Přidáme zeleninu a opálenou cibuli.|Scedíme, přidáme uvařené nudle, maso a petrželku."],
  ["Gulášová polévka", "Polévky", 90, "400 g hovězího, 2 cibule, 3 brambory, paprika, kmín, česnek, rajčatový protlak", "Cibuli osmahneme, přidáme maso a papriku.|Podlijeme vodou a dusíme.|Přidáme brambory na kostky a vaříme doměkka.|Dochutíme česnekem a majoránkou."],
  ["Čočková polévka", "Polévky", 50, "250 g čočky, 1 cibule, 2 brambory, česnek, majoránka, ocet, uzenina", "Čočku namočíme a uvaříme.|Přidáme brambory a orestovanou cibuli.|Zahustíme jíškou a dochutíme octem."],
  ["Zelňačka", "Polévky", 60, "300 g kysaného zelí, 3 brambory, klobása, cibule, paprika, kmín, smetana", "Cibuli a klobásu orestujeme, přidáme papriku.|Přidáme zelí, brambory a vodu.|Vaříme doměkka a zjemníme smetanou."],
  ["Rajská polévka", "Polévky", 40, "800 g rajčat, 1 cibule, 1 lžíce cukru, máslo, rýže, bazalka", "Cibuli zpěníme na másle, přidáme rajčata.|Povaříme a rozmixujeme.|Dochutíme cukrem, přidáme uvařenou rýži."],
  ["Hrachová polévka", "Polévky", 60, "300 g půleného hrachu, cibule, česnek, majoránka, uzené maso, krutony", "Hrách uvaříme doměkka s uzeným masem.|Rozmixujeme a dochutíme česnekem a majoránkou.|Podáváme s krutony."],
  ["Dršťková polévka", "Polévky", 120, "500 g drštěk, 2 cibule, paprika, česnek, majoránka, mouka, kmín", "Drštěky předvaříme a nakrájíme.|Uděláme cibulovou jíšku s paprikou.|Vaříme s drštěkami a dochutíme česnekem a majoránkou."],
  ["Brokolicový krém", "Polévky", 30, "1 brokolice, 2 brambory, 1 cibule, 500 ml vývaru, 100 ml smetany", "Cibuli zpěníme, přidáme brokolici a brambory.|Zalijeme vývarem a uvaříme.|Rozmixujeme a zjemníme smetanou."],
  ["Kuřecí vývar s játrovými knedlíčky", "Polévky", 120, "1 kuře, kořenová zelenina, 200 g kuřecích jater, 1 vejce, strouhanka, petrželka", "Kuře vaříme se zeleninou 1,5 hodiny.|Z jater, vejce a strouhanky uděláme knedlíčky.|Knedlíčky povaříme ve vývaru."],
  ["Fazolová polévka", "Polévky", 70, "300 g fazolí, cibule, 2 brambory, paprika, česnek, klobása", "Fazole namočíme přes noc a uvaříme.|Přidáme cibuli, brambory a klobásu.|Dochutíme česnekem a paprikou."],
  ["Dýňová polévka", "Polévky", 35, "1 dýně Hokkaido, cibule, zázvor, 500 ml vývaru, kokosové mléko", "Dýni s cibulí a zázvorem orestujeme.|Zalijeme vývarem a uvaříme doměkka.|Rozmixujeme s kokosovým mlékem."],
  ["Pečená kachna se zelím", "Hlavní chod", 180, "1 kachna, kmín, sůl, červené zelí, cibule, knedlíky", "Kachnu osolíme a posypeme kmínem.|Pečeme 3 hodiny, často podléváme.|Podáváme s dušeným zelím a knedlíkem."],
  ["Vepřo knedlo zelo", "Hlavní chod", 120, "1 kg vepřové plece, kmín, česnek, cibule, kysané zelí, houskový knedlík", "Maso potřeme česnekem, kmínem a solí.|Pečeme pod poklicí s cibulí.|Podáváme s dušeným zelím a knedlíkem."],
  ["Španělský ptáček", "Hlavní chod", 90, "4 plátky hovězího, slanina, párek, vejce, okurka, cibule, rýže", "Plátky naklepeme a naplníme slaninou, párkem, vejcem a okurkou.|Zavineme, opečeme a dusíme v omáčce.|Podáváme s rýží."],
  ["Koprovka s vejcem", "Hlavní chod", 30, "500 ml mléka, 2 lžíce mouky, máslo, kopr, ocet, vejce, brambory", "Z másla a mouky uděláme jíšku a zalijeme mlékem.|Povaříme, přidáme kopr a dochutíme octem.|Podáváme s vejcem a brambory."],
  ["Rajská omáčka s hovězím", "Hlavní chod", 120, "600 g hovězího, rajčatový protlak, cibule, nové koření, bobkový list, cukr, knedlík", "Maso uvaříme s kořením.|Uděláme jíšku, přidáme protlak a vývar.|Dochutíme cukrem a octem, podáváme s knedlíkem."],
  ["Kuře na paprice", "Hlavní chod", 60, "4 kuřecí stehna, 2 cibule, sladká paprika, smetana, mouka, těstoviny", "Cibuli osmahneme, přidáme papriku a kuře.|Podlijeme a dusíme doměkka.|Zahustíme smetanou s moukou, podáváme s těstovinami."],
  ["Bramboráky", "Hlavní chod", 40, "1 kg brambor, 2 vejce, 3 lžíce mouky, česnek, majoránka, sůl, olej", "Brambory nastrouháme a vymačkáme.|Smícháme s vejci, moukou, česnekem a majoránkou.|Smažíme tenké placky dozlatova."],
  ["Pečené kuře s nádivkou", "Hlavní chod", 120, "1 kuře, 4 rohlíky, 2 vejce, mléko, petrželka, máslo, brambory", "Rohlíky namočíme v mléce s vejci a petrželkou.|Nádivku vložíme pod kůži kuřete.|Pečeme 1,5 hodiny dozlatova."],
  ["Plněné papriky", "Hlavní chod", 75, "6 paprik, 500 g mletého masa, rýže, vejce, rajčatová omáčka, knedlík", "Maso smícháme s rýží a vejcem.|Naplníme papriky.|Dusíme v rajské omáčce 45 minut."],
  ["Segedínský guláš", "Hlavní chod", 90, "600 g vepřové plece, 500 g kysaného zelí, cibule, paprika, kmín, smetana, knedlík", "Maso s cibulí a paprikou podusíme.|Přidáme zelí a dusíme doměkka.|Zjemníme smetanou s moukou."],
  ["Karbanátky", "Hlavní chod", 40, "500 g mletého masa, rohlík, vejce, cibule, česnek, strouhanka, bramborová kaše", "Maso smícháme s namočeným rohlíkem, vejcem a cibulí.|Tvoříme placky, obalíme ve strouhance.|Smažíme a podáváme s kaší."],
  ["Kuřecí řízek", "Hlavní chod", 30, "4 kuřecí prsa, mouka, 2 vejce, strouhanka, olej, citron", "Prsa naklepeme a osolíme.|Obalíme v trojobalu.|Smažíme dozlatova."],
  ["Vepřová panenka na pepři", "Hlavní chod", 35, "600 g vepřové panenky, zelený pepř, smetana, máslo, koňak", "Panenku opečeme ze všech stran.|Přidáme pepř, koňak a smetanu.|Omáčku zredukujeme, podáváme s hranolky."],
  ["Znojemská pečeně", "Hlavní chod", 70, "4 plátky hovězího, cibule, kyselé okurky, mouka, rýže", "Plátky opečeme a dusíme s cibulí.|Přidáme nastrouhané okurky a zahustíme.|Podáváme s rýží."],
  ["Hovězí na houbách", "Hlavní chod", 100, "600 g hovězího, 300 g žampionů, cibule, smetana, tymián", "Maso orestujeme s cibulí.|Dusíme doměkka, přidáme houby.|Zjemníme smetanou."],
  ["Rizoto s kuřecím masem", "Hlavní chod", 40, "300 g rýže, 300 g kuřecího, hrášek, mrkev, cibule, vývar, parmazán", "Na cibuli orestujeme maso a zeleninu.|Přidáme rýži a postupně vývar.|Dokončíme parmazánem."],
  ["Svíčková z vepřového", "Hlavní chod", 120, "800 g vepřové kýty, kořenová zelenina, smetana, citron, brusinky, knedlík", "Maso a zeleninu opečeme.|Dusíme doměkka.|Zeleninu rozmixujeme se smetanou."],
  ["Těstoviny se špenátem", "Hlavní chod", 20, "400 g těstovin, 300 g špenátu, česnek, smetana, parmazán", "Uvaříme těstoviny.|Na česneku podusíme špenát se smetanou.|Smícháme a posypeme parmazánem."],
  ["Bramborové knedlíky se zelím a uzeným", "Hlavní chod", 60, "1 kg brambor, mouka, vejce, uzené maso, kysané zelí, cibule", "Z vařených brambor, mouky a vejce uděláme těsto.|Vaříme knedlíky.|Podáváme s uzeným a dušeným zelím."],
  ["Pstruh na másle", "Hlavní chod", 30, "4 pstruzi, máslo, citron, petrželka, brambory", "Pstruhy osolíme a obalíme v mouce.|Opečeme na másle.|Podáváme s brambory a citronem."],
  ["Pečená vepřová žebra", "Hlavní chod", 150, "1,5 kg žeber, med, česnek, sójová omáčka, pivo, chilli", "Žebra potřeme marinádou.|Pečeme pod alobalem 2 hodiny.|Odkryjeme a dopečeme dozlatova."],
  ["Lečo s vejci", "Hlavní chod", 30, "4 papriky, 3 rajčata, cibule, klobása, 4 vejce", "Cibuli a klobásu orestujeme.|Přidáme papriky a rajčata.|Vmícháme vejce a podáváme s chlebem."],
  ["Francouzské brambory", "Hlavní chod", 60, "1 kg brambor, 300 g uzeného masa, 4 vejce, smetana, sýr", "Vrstvíme vařené brambory a uzené.|Zalijeme vejci se smetanou.|Zapékáme 30 minut."],
  ["Čočka na kyselo s vejcem", "Hlavní chod", 50, "400 g čočky, cibule, mouka, ocet, cukr, vejce, okurka", "Čočku uvaříme.|Zahustíme jíškou a dochutíme octem a cukrem.|Podáváme s volským okem a okurkou."],
  ["Buchtičky se šodó", "Dezerty", 60, "500 g mouky, kvasnice, mléko, cukr, máslo, vejce, víno na šodó", "Uděláme kynuté těsto a necháme vykynout.|Tvoříme buchtičky a pečeme.|Podáváme s vinným krémem."],
  ["Jablečný štrúdl", "Dezerty", 60, "listové těsto, 1 kg jablek, skořice, cukr, rozinky, ořechy", "Jablka nastrouháme se skořicí a cukrem.|Rozložíme na těsto s rozinkami a ořechy.|Zabalíme a pečeme 40 minut."],
  ["Ovocné knedlíky", "Dezerty", 45, "500 g tvarohu, 250 g krupice, vejce, jahody nebo švestky, máslo, cukr", "Z tvarohu, krupice a vejce uděláme těsto.|Obalíme ovoce a vaříme 8 minut.|Podáváme s máslem, cukrem a tvarohem."],
  ["Bábovka", "Dezerty", 70, "250 g mouky, 200 g cukru, 4 vejce, 200 ml mléka, olej, kakao, prášek do pečiva", "Smícháme těsto, polovinu obarvíme kakaem.|Vrstvíme do formy.|Pečeme 50 minut při 170 °C."],
  ["Koláče s tvarohem", "Dezerty", 90, "500 g mouky, kvasnice, mléko, máslo, tvaroh, žloutek, cukr, posýpka", "Uděláme kynuté těsto.|Tvoříme koláčky s tvarohovou náplní.|Posypeme drobenkou a pečeme."],
  ["Perník", "Dezerty", 50, "300 g mouky, 200 g cukru, 2 vejce, med, mléko, perníkové koření, kakao", "Smícháme všechny suroviny.|Nalijeme na plech.|Pečeme 30 minut, polijeme čokoládou."],
  ["Lívance s borůvkami", "Dezerty", 30, "300 g mouky, 400 ml mléka, 2 vejce, kvasnice, borůvky, zakysaná smetana", "Uděláme řídké kynuté těsto.|Smažíme malé placky na pánvi.|Podáváme s borůvkami a smetanou."],
  ["Bublanina", "Dezerty", 45, "4 vejce, 150 g cukru, 150 g mouky, máslo, sezónní ovoce", "Vyšleháme vejce s cukrem, vmícháme mouku a máslo.|Nalijeme na plech a posypeme ovocem.|Pečeme 25 minut."],
  ["Větrníky", "Dezerty", 90, "odpalované těsto, vanilkový krém, karamel, šlehačka", "Upečeme odpalované kuličky.|Naplníme krémem a šlehačkou.|Polijeme karamelem."],
  ["Kremrole", "Dezerty", 60, "listové těsto, 3 bílky, 200 g cukru, moučkový cukr", "Těsto namotáme na kornoutky a upečeme.|Ušleháme bílkový sníh s cukrem.|Naplníme kremrole."],
  ["Rakvičky se šlehačkou", "Dezerty", 60, "4 vejce, 200 g cukru, 50 g mouky, šlehačka", "Ušleháme piškotové těsto.|Pečeme rakvičky na plechu.|Plníme šlehačkou."],
  ["Vánočka", "Dezerty", 180, "1 kg mouky, kvasnice, mléko, máslo, cukr, vejce, rozinky, mandle", "Uděláme kynuté těsto s rozinkami.|Spleteme cop z pramenů.|Pečeme 50 minut."],
  ["Tvarohová bábovka", "Dezerty", 70, "250 g tvarohu, 3 vejce, 200 g cukru, 250 g mouky, olej, citronová kůra", "Smícháme tvaroh s vejci a cukrem.|Přidáme mouku a olej.|Pečeme v bábovkové formě."],
  ["Švestkový koláč s drobenkou", "Dezerty", 60, "kynuté těsto, 1 kg švestek, mouka, máslo, cukr, skořice", "Těsto rozválíme na plech.|Pokládáme půlené švestky.|Posypeme drobenkou a pečeme."],
  ["Medovník", "Dezerty", 120, "500 g mouky, med, máslo, vejce, jedlá soda, kondenzované mléko, ořechy", "Upečeme tenké medové pláty.|Promažeme krémem.|Necháme přes noc odležet."],
  ["Jahodové tiramisu", "Dezerty", 30, "piškoty, mascarpone, jahody, cukr, šlehačka", "Piškoty namočíme v jahodovém pyré.|Vrstvíme s krémem a jahodami.|Necháme vychladit."],
];

export const moreRecipes: Recipe[] = raw.map(([title, category, time, ing, steps], i) => ({
  id: `m${i + 1}`,
  title,
  category,
  time,
  image: imageFor(i, category),
  ingredients: ing.split(",").map((s) => s.trim()),
  instructions: steps.split("|").map((s, j) => `${j + 1}. ${s}`).join("\n"),
  favorite: false,
}));
