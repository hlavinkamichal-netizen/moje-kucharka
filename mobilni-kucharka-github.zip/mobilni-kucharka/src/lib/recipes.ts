import svickova from "@/assets/svickova.jpg";
import gulas from "@/assets/gulas.jpg";
import bramboracka from "@/assets/bramboracka.jpg";
import palacinky from "@/assets/palacinky.jpg";
import rizek from "@/assets/rizek.jpg";
import syr from "@/assets/smazeny-syr.jpg";

export type Category = "Hlavní chod" | "Polévky" | "Dezerty";
export interface Recipe {
  id: string;
  title: string;
  category: Category;
  time: number;
  image: string;
  ingredients: string[];
  instructions: string;
  favorite: boolean;
}

export const FALLBACK_IMAGE = palacinky;

export const defaultRecipes: Recipe[] = [
  { id: "1", title: "Svíčková na smetaně", category: "Hlavní chod", time: 120, image: svickova, favorite: true,
    ingredients: ["800g hovězí zadní", "200g kořenové zeleniny (mrkev, celer, petržel)", "200ml smetany ke šlehání", "100g špeku/slaniny", "citron", "brusinky", "houskový knedlík"],
    instructions: "1. Maso prošpikujeme klínky slaniny, osolíme a opepříme.\n2. Zeleninu nakrájíme a orestujeme do zlatohněda.\n3. Maso zprudka opečeme, podlijeme vývarem a dusíme doměkka.\n4. Maso vyjmeme, zeleninu rozmixujeme na hladkou omáčku, zjemníme smetanou a dochutíme citronem. Podáváme s knedlíkem a brusinkami." },
  { id: "2", title: "Tradiční hovězí guláš", category: "Hlavní chod", time: 90, image: gulas, favorite: false,
    ingredients: ["600g hovězí kližky", "500g cibule", "2 lžíce sladké mleté papriky", "3 stroužky česneku", "majoránka", "houskový knedlík nebo chléb"],
    instructions: "1. Na sádle osmažíme cibulku do tmavě hnědé barvy.\n2. Přidáme nakrájené hovězí maso, zaprášíme paprikou a orestujeme.\n3. Podlijeme vývarem a dusíme cca 1,5 hodiny do úplného změknutí.\n4. Dochutíme prolisovaným česnekem, majoránkou a podáváme s houskovým knedlíkem." },
  { id: "3", title: "Poctivá bramboračka s houbami", category: "Polévky", time: 40, image: bramboracka, favorite: false,
    ingredients: ["4 brambory", "1 hrst sušených lesních hub", "2 mrkve", "1 petržel", "1/4 celeru", "3 stroužky česneku", "majoránka", "jíška"],
    instructions: "1. Houby namočíme do vody. Zeleninu a brambory nakrájíme na kostičky.\n2. Zeleninu dáme vařit do osolené vody s houbami a kmínem.\n3. Zahustíme tmavší jíškou a povaříme 15 minut.\n4. Nakonec dochutíme třeným česnekem a rozetřenou majoránkou." },
  { id: "4", title: "Nadýchané palačinky s džemem", category: "Dezerty", time: 25, image: palacinky, favorite: true,
    ingredients: ["500ml mléka", "200g hladké mouky", "2 vejce", "špetka soli", "ovocný džem", "moučkový cukr"],
    instructions: "1. Mléko, mouku, vejce a sůl vyšleháme na hladké těsto a necháme 10 minut odpočinout.\n2. Na rozpálené pánvi potřené kapkou oleje smažíme tenké palačinky z obou stran.\n3. Potřeme džemem, zavineme a posypeme cukrem." },
  { id: "5", title: "Křupavý vepřový řízek", category: "Hlavní chod", time: 30, image: rizek, favorite: false,
    ingredients: ["500g vepřové krkovičky nebo pečeně", "2 vejce", "100g hladké mouky", "150g strouhanky", "bramborový salát nebo kaše", "citron"],
    instructions: "1. Maso lehce naklepeme, osolíme a opepříme.\n2. Obalíme postupně v hladké mouce, rozšlehaných vejcích a strouhance.\n3. Smažíme na sádle nebo oleji dozlatova z obou stran. Podáváme s citronem." },
  { id: "6", title: "Smažený sýr s tatarkou", category: "Hlavní chod", time: 20, image: syr, favorite: true,
    ingredients: ["400g eidam 30%", "2 vejce", "hladká mouka", "strouhanka", "tatarská omáčka", "hranolky"],
    instructions: "1. Plátky sýra obalíme v trojobalu (mouka, vejce, strouhanka) dvakrát za sebou, aby sýr při smažení nevytekal.\n2. Smažíme v rozpáleném oleji dozlatova z obou stran.\n3. Podáváme s tatarskou omáčkou a hranolky." },
];
